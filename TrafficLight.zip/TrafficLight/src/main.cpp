#include <Arduino.h>

// Deklarasi pin LED sesuai koneksi di Wokwi
int ledMerah = 26;
int ledKuning = 33; 
int ledHijau = 25;  

void setup() {
    Serial.begin(115200);  // Inisialisasi komunikasi Serial
    Serial.println("ESP32 Traffic Light Simulation");

    // Atur pin sebagai OUTPUT
    pinMode(ledMerah, OUTPUT);
    pinMode(ledKuning, OUTPUT);
    pinMode(ledHijau, OUTPUT);

    // Pastikan semua lampu mati saat mulai
    digitalWrite(ledMerah, LOW);
    digitalWrite(ledKuning, LOW);
    digitalWrite(ledHijau, LOW);
}

void loop() {
    // Lampu Merah menyala selama 5 detik
    digitalWrite(ledMerah, HIGH);
    Serial.println("Lampu Merah ON");
    delay(5000);

    // Matikan Lampu Merah sebelum menyalakan Lampu Kuning
    digitalWrite(ledMerah, LOW);
    delay(500);  

    // Lampu Kuning menyala selama 3 detik
    digitalWrite(ledKuning, HIGH);
    Serial.println("Lampu Kuning ON");

    // Debug: Periksa apakah LED Kuning benar-benar menyala
    if (digitalRead(ledKuning) == HIGH) {
        Serial.println("DEBUG: LED Kuning menyala dengan benar");
    } else {
        Serial.println("DEBUG: LED Kuning TIDAK menyala, cek koneksi!");
    }

    delay(3000);

    // Matikan Lampu Kuning sebelum menyalakan Lampu Hijau
    digitalWrite(ledKuning, LOW);
    delay(500);  

    // Lampu Hijau menyala selama 5 detik
    digitalWrite(ledHijau, HIGH);
    Serial.println("Lampu Hijau ON");
    delay(5000);

    // Matikan Lampu Hijau sebelum siklus dimulai lagi
    digitalWrite(ledHijau, LOW);
    delay(500);  
}